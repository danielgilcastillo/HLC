


package pruebaprincipiossolid;


class DispositivoLog implements Iguardar {
    @Override
    public void guardarLog(String mensaje) {
// Guardar el log en un archivo (violación de SRP, la clase tiene dos responsabilidades)
        System.out.println("Guardando log: " + mensaje);
    }

}
