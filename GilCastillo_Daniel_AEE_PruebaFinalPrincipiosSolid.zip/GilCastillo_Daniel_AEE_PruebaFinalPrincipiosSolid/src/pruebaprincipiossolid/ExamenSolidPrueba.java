
package pruebaprincipiossolid;


public class ExamenSolidPrueba {

    public static void main(String[] args) {
       
        
        Idispositivo x=new Calefaccion(true);
        Termostato t=new Termostato(x);
        
        Iiluminar a = new DispositivoIluminar();
        Iguardar b= new DispositivoLog();
        t.presionar( a , b );
        
        
    }

}
