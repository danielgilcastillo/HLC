


package pruebaprincipiossolid;


class Calefaccion implements Idispositivo {

    private boolean encendida = false;

    public Calefaccion(boolean encendida) {
        this.encendida = encendida;
    }

    public boolean isEncendida() {
        return encendida;
    }

    public void setEncendida(boolean encendida) {
        this.encendida = encendida;
    }

}
