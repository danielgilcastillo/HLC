


package pruebaprincipiossolid;


class DispositivoIluminar implements Iiluminar {


    @Override
    public void encender(Idispositivo cale, Iguardar log) {
        cale.setEncendida(true);
        System.out.println("Calefacción encendida");
        log.guardarLog("Calefacción encendida");
    }

    @Override
    public void apagar(Idispositivo cale, Iguardar log) {
        cale.setEncendida(false);
        System.out.println("Calefacción apagada");
        log.guardarLog("Calefacción apagada");
    }
}
