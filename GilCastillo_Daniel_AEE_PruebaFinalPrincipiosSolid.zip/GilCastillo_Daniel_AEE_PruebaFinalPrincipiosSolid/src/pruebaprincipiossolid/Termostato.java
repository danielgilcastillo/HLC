


package pruebaprincipiossolid;


class Termostato {

    private Idispositivo dispo;

    public Termostato(Idispositivo dispo) {
        this.dispo = dispo;
    }

    public void presionar(Iiluminar d , Iguardar log ) {
        if (dispo.isEncendida()) {
            d.apagar(  dispo ,log   );
        } else {
            d.encender(dispo ,log  );
        }
    }
}
